
Licensed under the apache-2.0 license, except as noted below.  

Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright/ digital rights 
legend, this list of conditions and the following Notice.

* Redistributions in binary form must reproduce the above copyright copyright/digital 
rights legend, this list of conditions and the following Notice in the documentation 
and/or other materials provided with the distribution.

* Neither the name of The MITRE Corporation nor the names of its contributors may be 
used to endorse or promote products derived from this software without specific prior 
written permission.
